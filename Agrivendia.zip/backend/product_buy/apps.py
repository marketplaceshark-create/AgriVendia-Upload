from django.apps import AppConfig


class ProductBuyConfig(AppConfig):
    name = "product_buy"
