from django.apps import AppConfig


class ProductSellConfig(AppConfig):
    name = "product_sell"
