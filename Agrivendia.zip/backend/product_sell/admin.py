# Path: backend/product_sell/admin.py
from django.contrib import admin
from .models import ProductSell

admin.site.register(ProductSell)