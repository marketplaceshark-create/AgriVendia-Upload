from django.apps import AppConfig


class ProductBidConfig(AppConfig):
    name = "product_bid"
